Controls:
Movement: Arrow Keys <br>
A: X <br>
B: C <br>
R: Q <br>
Z: Space <br>
Start: Enter <br>
C-stick: WASD
